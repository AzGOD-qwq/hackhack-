# hackhack

this client is basically a monkey skid by retarded devs who think making a chat suffix is a big deal. this client used to be gamesense base, but they claimed to have "rewritten" it and now it's a "custom base". apparently custom base means take gamesense and remove all the modules. this client pretty much only has broken and pasted modules.

# the devs

all of them are shit coders except max who actually knows java, i wish i had taken screenshots of the retarded monkey shit that they said in the group chat. the main dev doesn't even know java and pretty much just skids from other clients. jake knows java too ig

# why i leaked

the main "dev" kept removing me from the repo and the group chat thinking i would leak it, i had no intention of leaking it till he removed from the repo. you brought this upon yourself big man.
