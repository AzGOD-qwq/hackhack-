package me.zoom.hackhack.util.friend;

public class Friend {

    String name;
    public Friend(String n){
        name = n;
    }

    public String getName(){
        return name;
    }
}
