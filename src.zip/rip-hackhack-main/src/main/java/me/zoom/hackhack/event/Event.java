package me.zoom.hackhack.event;

import me.zero.alpine.type.Cancellable;

public class Event extends Cancellable {

    public Event() {
    }
}