package me.zoom.hackhack.module.modules.HudEditor;

import me.zoom.hackhack.module.Module;

public class HudEditor extends Module {
    public HudEditor() {
        super("Hud Editor", Category.HudEditor);
    }
}
