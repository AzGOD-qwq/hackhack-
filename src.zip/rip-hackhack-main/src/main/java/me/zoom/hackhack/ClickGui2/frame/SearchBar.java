package me.zoom.hackhack.ClickGui2.frame;

public class SearchBar {
}
